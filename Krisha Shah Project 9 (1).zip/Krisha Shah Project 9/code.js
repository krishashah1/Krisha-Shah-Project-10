var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["20b9b019-f388-46ee-9bdf-e8c66a79aa89"],"propsByKey":{"20b9b019-f388-46ee-9bdf-e8c66a79aa89":{"name":"frog","sourceUrl":null,"frameSize":{"x":388,"y":313},"frameCount":1,"looping":true,"frameDelay":12,"version":"SmbWEFKKC0h.DPYDg1UrGS2rdaus33F0","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":313},"rootRelativePath":"assets/20b9b019-f388-46ee-9bdf-e8c66a79aa89.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life=0;
//creating the player pacman
var pacman = createSprite(20, 25, 18, 18);
pacman.shapeColor="yellow";
//creating the walls(wall1 - wall22)
var wall1 = createSprite(10, 70, 100, 20);
  wall1.shapeColor="blue";
var wall2 = createSprite(100, 50, 20, 100);
  wall2.shapeColor="blue";
var wall3 = createSprite(300, 90, 20, 90);
  wall3.shapeColor="blue";
var wall4 = createSprite(200, 120, 20, 90);
  wall4.shapeColor = "blue";
var wall5 = createSprite(350, 30, 20, 100);
  wall5.shapeColor = "blue";
var wall6 = createSprite(300, 370, 20, 90);
  wall6.shapeColor = "blue";
var wall7= createSprite(180, 290, 20, 90);
  wall7.shapeColor = "blue";
var wall8 = createSprite(205, 390, 100, 20);
  wall8.shapeColor = "blue";
var wall9 = createSprite(115, 335, 20, 100);
  wall9.shapeColor = "blue";
var wall10 = createSprite(300, 235, 20, 90);
  wall10.shapeColor = "blue";
var wall11 = createSprite(200, 205, 100, 20);
  wall11.shapeColor = "blue";
var wall12 = createSprite(355, 220, 100, 20);
  wall12.shapeColor = "blue";
var wall13 = createSprite(215, 20, 100, 20);
  wall13.shapeColor = "blue";
var wall14 = createSprite(150, 115, 100, 20);
  wall14.shapeColor = "blue";
var wall15 = createSprite(340, 115, 100, 25);
  wall15.shapeColor = "blue";
var wall16 = createSprite(220, 310, 100, 25);
  wall16.shapeColor = "blue";
var wall17 = createSprite(40, 145, 20, 90);
  wall17.shapeColor = "blue";
var wall18 = createSprite(70, 250, 120, 20);
  wall18.shapeColor = "blue";
var wall19 = createSprite(25, 325, 80, 20);
  wall19.shapeColor = "blue";
var wall20 = createSprite(80, 360, 90, 20);
  wall20.shapeColor = "blue";
var wall21 = createSprite(70, 205, 20, 70);
  wall21.shapeColor = "blue";
var wall22 = createSprite(20, 300, 20, 50);
  wall22.shapeColor = "blue";
//creating enemies(enemie1-enemie7)
var enemie1 = createSprite(260, 116, 20, 20);
enemie1.shapeColor="red";
var enemie2 = createSprite(245, 250, 20, 20);
enemie2.shapeColor="red";
var enemie3 = createSprite(360, 270, 20, 20);
enemie3.shapeColor="red";
var enemie4 = createSprite(70, 285, 20, 20);
enemie4.shapeColor="red";
var enemie5 = createSprite(140, 310, 20, 20);
enemie5.shapeColor="red";
var enemie6 = createSprite(20, 200, 20, 20);
enemie6.shapeColor="red";
var enemie7 = createSprite(145, 55, 20, 20);
enemie7.shapeColor="red";
//create trophy
var trophy = createSprite(395, 390, 50, 50);
trophy.shapeColor = "orange";
//add the velocity to make the enemie move.
enemie1.velocityX=2;
enemie2.velocityX=2;
enemie3.velocityX=-2;
enemie4.velocityX=-2;
enemie5.velocityX=2;
enemie6.velocityX=-2;
enemie7.velocityX=2;

function draw(){
background("lightgray");
pacman.bounceOff(wall1);
pacman.bounceOff(wall2);
pacman.bounceOff(wall3);
pacman.bounceOff(wall4);
pacman.bounceOff(wall5);
pacman.bounceOff(wall6);
pacman.bounceOff(wall7);
pacman.bounceOff(wall8);
pacman.bounceOff(wall9);
pacman.bounceOff(wall10);
pacman.bounceOff(wall11);
pacman.bounceOff(wall12);
pacman.bounceOff(wall13);
pacman.bounceOff(wall14);
pacman.bounceOff(wall15);
pacman.bounceOff(wall16);
pacman.bounceOff(wall17);
pacman.bounceOff(wall18);
pacman.bounceOff(wall19);
pacman.bounceOff(wall20);
pacman.bounceOff(wall21);
pacman.bounceOff(wall22);
enemie1.bounceOff(wall1);
enemie1.bounceOff(wall2);
enemie1.bounceOff(wall3);
enemie1.bounceOff(wall4);
enemie1.bounceOff(wall5);
enemie1.bounceOff(wall6);
enemie1.bounceOff(wall7);
enemie1.bounceOff(wall8);
enemie1.bounceOff(wall9);
enemie1.bounceOff(wall10);
enemie1.bounceOff(wall11);
enemie1.bounceOff(wall12);
enemie1.bounceOff(wall13);
enemie1.bounceOff(wall14);
enemie1.bounceOff(wall15);
enemie1.bounceOff(wall16);
enemie1.bounceOff(wall17);
enemie1.bounceOff(wall18);
enemie1.bounceOff(wall19);
enemie1.bounceOff(wall20);
enemie1.bounceOff(wall21);
enemie1.bounceOff(wall22);
enemie2.bounceOff(wall1);
enemie2.bounceOff(wall2);
enemie2.bounceOff(wall3);
enemie2.bounceOff(wall4);
enemie2.bounceOff(wall5);
enemie2.bounceOff(wall6);
enemie2.bounceOff(wall7);
enemie2.bounceOff(wall8);
enemie2.bounceOff(wall9);
enemie2.bounceOff(wall10);
enemie2.bounceOff(wall11);
enemie2.bounceOff(wall12);
enemie2.bounceOff(wall13);
enemie2.bounceOff(wall14);
enemie2.bounceOff(wall15);
enemie2.bounceOff(wall16);
enemie2.bounceOff(wall17);
enemie2.bounceOff(wall18);
enemie2.bounceOff(wall19);
enemie2.bounceOff(wall20);
enemie2.bounceOff(wall21);
enemie2.bounceOff(wall22);
enemie3.bounceOff(wall1);
enemie3.bounceOff(wall2);
enemie3.bounceOff(wall3);
enemie3.bounceOff(wall4);
enemie3.bounceOff(wall5);
enemie3.bounceOff(wall6);
enemie3.bounceOff(wall7);
enemie3.bounceOff(wall8);
enemie3.bounceOff(wall9);
enemie3.bounceOff(wall10);
enemie3.bounceOff(wall11);
enemie3.bounceOff(wall12);
enemie3.bounceOff(wall13);
enemie3.bounceOff(wall14);
enemie3.bounceOff(wall15);
enemie3.bounceOff(wall16);
enemie3.bounceOff(wall17);
enemie3.bounceOff(wall18);
enemie3.bounceOff(wall19);
enemie3.bounceOff(wall20);
enemie3.bounceOff(wall21);
enemie3.bounceOff(wall22);
enemie4.bounceOff(wall1);
enemie4.bounceOff(wall2);
enemie4.bounceOff(wall3);
enemie4.bounceOff(wall4);
enemie4.bounceOff(wall5);
enemie4.bounceOff(wall6);
enemie4.bounceOff(wall7);
enemie4.bounceOff(wall8);
enemie4.bounceOff(wall9);
enemie4.bounceOff(wall10);
enemie4.bounceOff(wall11);
enemie4.bounceOff(wall12);
enemie4.bounceOff(wall13);
enemie4.bounceOff(wall14);
enemie4.bounceOff(wall15);
enemie4.bounceOff(wall16);
enemie4.bounceOff(wall17);
enemie4.bounceOff(wall18);
enemie4.bounceOff(wall19);
enemie4.bounceOff(wall20);
enemie4.bounceOff(wall21);
enemie4.bounceOff(wall22);
enemie5.bounceOff(wall1);
enemie5.bounceOff(wall2);
enemie5.bounceOff(wall3);
enemie5.bounceOff(wall4);
enemie5.bounceOff(wall5);
enemie5.bounceOff(wall6);
enemie5.bounceOff(wall7);
enemie5.bounceOff(wall8);
enemie5.bounceOff(wall9);
enemie5.bounceOff(wall10);
enemie5.bounceOff(wall11);
enemie5.bounceOff(wall12);
enemie5.bounceOff(wall13);
enemie5.bounceOff(wall14);
enemie5.bounceOff(wall15);
enemie5.bounceOff(wall16);
enemie5.bounceOff(wall17);
enemie5.bounceOff(wall18);
enemie5.bounceOff(wall19);
enemie5.bounceOff(wall20);
enemie5.bounceOff(wall21);
enemie5.bounceOff(wall22);
enemie6.bounceOff(wall1);
enemie6.bounceOff(wall2);
enemie6.bounceOff(wall3);
enemie6.bounceOff(wall4);
enemie6.bounceOff(wall5);
enemie6.bounceOff(wall6);
enemie6.bounceOff(wall7);
enemie6.bounceOff(wall8);
enemie6.bounceOff(wall9);
enemie6.bounceOff(wall10);
enemie6.bounceOff(wall11);
enemie6.bounceOff(wall12);
enemie6.bounceOff(wall13);
enemie6.bounceOff(wall14);
enemie6.bounceOff(wall15);
enemie6.bounceOff(wall16);
enemie6.bounceOff(wall17);
enemie6.bounceOff(wall18);
enemie6.bounceOff(wall19);
enemie6.bounceOff(wall20);
enemie6.bounceOff(wall21);
enemie6.bounceOff(wall22);
enemie7.bounceOff(wall1);
enemie7.bounceOff(wall2);
enemie7.bounceOff(wall3);
enemie7.bounceOff(wall4);
enemie7.bounceOff(wall5);
enemie7.bounceOff(wall6);
enemie7.bounceOff(wall7);
enemie7.bounceOff(wall8);
enemie7.bounceOff(wall9);
enemie7.bounceOff(wall10);
enemie7.bounceOff(wall11);
enemie7.bounceOff(wall12);
enemie7.bounceOff(wall13);
enemie7.bounceOff(wall14);
enemie7.bounceOff(wall15);
enemie7.bounceOff(wall16);
enemie7.bounceOff(wall17);
enemie7.bounceOff(wall18);
enemie7.bounceOff(wall19);
enemie7.bounceOff(wall20);
enemie7.bounceOff(wall21);
enemie7.bounceOff(wall22);
createEdgeSprites();
pacman.bounceOff(edges);
enemie1.bounceOff(edges);
enemie2.bounceOff(edges);
enemie3.bounceOff(edges);
enemie4.bounceOff(edges);
enemie5.bounceOff(edges);
enemie6.bounceOff(edges);
enemie7.bounceOff(edges);


if (keyDown("up")) {
   pacman.y=pacman.y-4; 
  }
if (keyDown("down")) {
    pacman.y=pacman.y+4;
  }
if (keyDown("left")) {
   pacman.x=pacman.x-4;
  }
if (keyDown("right")) {
    pacman.x=pacman.x+4; 
}

 //Add the condition to reduce the life of pacman if it touches the enemie.
  if(pacman.isTouching(enemie1)||pacman.isTouching(enemie2)||pacman.isTouching(enemie3)||pacman.isTouching(enemie4)||pacman.isTouching(enemie5)||pacman.isTouching(enemie6)||pacman.isTouching(enemie7)){
    life=life+1;
    pacman.x=20;
    pacman.y=25;
  }
  text("Lives: " + life,15,390);
  
  if ( pacman.isTouching(trophy))  
{
  textSize(40);
  stroke("yellow");
  fill("yellow");
  text("You Win", 200, 200);
  
  }
  
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
